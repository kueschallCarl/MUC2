package com.K05.Mais_Maze_Android_App;


/**
 * This class provides some useful constants for the project
 */
public class Constants {
    public static final String MPU_TOPIC = "mpu/K05";
    public static final String TEMP_TOPIC = "temp/K05";
    public static final String FINISHED_TOPIC = "finished/K05";

}
